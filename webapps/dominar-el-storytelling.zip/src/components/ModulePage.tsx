import React from 'react';
import ReactMarkdown from 'react-markdown';
import { motion } from 'motion/react';
import { Module } from '../constants';
import { PyodideTool } from './PyodideTool';
import { ArrowLeft, Zap } from 'lucide-react';

interface ModulePageProps {
  module: Module;
  onBack: () => void;
}

export const ModulePage: React.FC<ModulePageProps> = ({ module, onBack }) => {
  return (
    <div className="min-h-screen bg-bg-pure text-text-main font-ubuntu">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-bg-pure/80 backdrop-blur-md border-b border-borde px-6 py-4">
        <div className="max-w-5xl mx-auto flex justify-between items-center">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-text-dim hover:text-accent-primary transition-colors font-bold uppercase text-xs tracking-widest"
          >
            <ArrowLeft size={16} />
            Volver al Inicio
          </button>
          <div className="text-accent-primary font-black text-sm tracking-widest uppercase">
            Módulo {module.id}
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-6 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Content */}
          <div className="markdown-body mb-24">
            <ReactMarkdown>{module.content}</ReactMarkdown>
          </div>

          {/* Tool Section */}
          {module.toolId && (
            <section className="mt-24 pt-24 border-t border-borde">
              <div className="flex items-center gap-4 mb-12">
                <div className="w-12 h-12 bg-accent-primary/10 rounded-2xl flex items-center justify-center text-accent-primary">
                  <Zap size={24} />
                </div>
                <div>
                  <h2 className="text-3xl font-black tracking-tight">HERRAMIENTA INTERACTIVA</h2>
                  <p className="text-text-dim uppercase text-[10px] tracking-[0.3em] font-bold">Potenciada por Statux Engine (Python)</p>
                </div>
              </div>
              
              <div className="bg-bg-card border border-borde rounded-3xl p-8 md:p-12 shadow-2xl shadow-accent-primary/5">
                <PyodideTool toolId={module.toolId} />
              </div>
              
              <div className="mt-8 text-center">
                <p className="text-text-dim text-sm italic">
                  * Las herramientas se cargan bajo demanda para optimizar el rendimiento.
                </p>
              </div>
            </section>
          )}
        </motion.div>
      </main>

      {/* Footer Navigation */}
      <div className="border-t border-borde py-12 px-6 mt-24">
        <div className="max-w-5xl mx-auto flex justify-center">
          <button 
            onClick={onBack}
            className="bg-bg-card border border-borde text-text-main px-12 py-4 rounded-full font-bold hover:border-accent-primary transition-all uppercase tracking-widest text-xs"
          >
            Finalizar y Volver
          </button>
        </div>
      </div>
    </div>
  );
};
