import React from 'react';
import { motion } from 'motion/react';
import { MODULES, Module } from '../constants';
import { ArrowRight, BookOpen, Zap, Target, Heart, ShoppingCart, Edit3, Layers, BarChart3 } from 'lucide-react';

interface LandingPageProps {
  onSelectModule: (module: Module) => void;
}

const ICONS = [Zap, Target, BookOpen, Heart, ShoppingCart, Edit3, Layers, BarChart3];

export const LandingPage: React.FC<LandingPageProps> = ({ onSelectModule }) => {
  return (
    <div className="min-h-screen bg-bg-pure text-text-main font-ubuntu selection:bg-accent-primary selection:text-bg-pure">
      {/* Hero Section */}
      <section className="relative py-24 px-6 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full pointer-events-none">
          <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-accent-primary/10 blur-[120px] rounded-full"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-accent-secondary/10 blur-[120px] rounded-full"></div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-accent-primary text-xs font-black uppercase tracking-[0.4em] mb-6 block">Statux Academy</span>
            <h1 className="text-5xl md:text-7xl font-black mb-8 tracking-tighter leading-none">
              DOMINAR EL <br />
              <span className="text-accent-primary">STORYTELLING</span>
            </h1>
            <p className="text-text-dim text-lg md:text-xl max-w-2xl mx-auto mb-12 leading-relaxed">
              No cuentes historias. Programa emociones. Domina la tecnología cognitiva milenaria para influir, persuadir y vender.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Modules Grid */}
      <section className="max-w-7xl mx-auto px-6 pb-32">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {MODULES.map((module, index) => {
            const Icon = ICONS[index];
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                onClick={() => onSelectModule(module)}
                className="group relative bg-bg-card border border-borde p-8 rounded-2xl cursor-pointer hover:border-accent-primary/50 transition-all duration-500 overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
                  <Icon size={120} />
                </div>
                
                <div className="relative z-10">
                  <div className="w-12 h-12 bg-bg-pure border border-borde rounded-xl flex items-center justify-center mb-6 group-hover:border-accent-primary group-hover:text-accent-primary transition-colors">
                    <Icon size={24} />
                  </div>
                  
                  <h3 className="text-xl font-bold mb-3 group-hover:text-accent-primary transition-colors">
                    {module.title}
                  </h3>
                  
                  <p className="text-text-dim text-sm leading-relaxed mb-8">
                    {module.description}
                  </p>
                  
                  <div className="flex items-center text-xs font-black uppercase tracking-widest text-accent-primary gap-2">
                    Explorar Módulo
                    <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>

                {/* Hover Glow */}
                <div className="absolute inset-0 bg-gradient-to-br from-accent-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-borde py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-accent-primary rounded flex items-center justify-center font-black text-bg-pure">S</div>
            <span className="font-black tracking-tighter text-xl">STATUX</span>
          </div>
          <p className="text-text-dim text-sm">© 2026 Statux Academy. El arte de la narrativa estratégica.</p>
        </div>
      </footer>
    </div>
  );
};
