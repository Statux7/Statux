import React, { useState } from 'react';

export default function StoryEngine({ pyodide }: { pyodide: any }) {
  const [step, setStep] = useState(1);
  const [data, setData] = useState({ protagonist: '', desire: '', conflict: '', risk: '', resolution: '' });
  const [result, setResult] = useState('');

  const generate = async () => {
    try {
      pyodide.globals.set("p", data.protagonist || "Un viajero desconocido");
      pyodide.globals.set("d", data.desire || "algo imposible");
      pyodide.globals.set("c", data.conflict || "el mundo se opone");
      pyodide.globals.set("r", data.risk || "todo se perderá");
      pyodide.globals.set("rs", data.resolution || "todo continúa");

      const code = `
def historia(p, d, c, r, rs):
    return f"{p} deseaba {d}.\\n\\nPero {c}.\\n\\nSi fallaba, {r}.\\n\\nAsí que decidió actuar.\\n\\nAl final, {rs}."
historia(p,d,c,r,rs)`;
      const res = await pyodide.runPythonAsync(code);
      setResult(res);
    } catch (e) {
      setResult("Error en el motor narrativo.");
    }
  };

  if (step > 5) {
    return (
      <div className="bg-bg-card p-8 border-l-4 border-accent-primary rounded-r-xl">
        <h3 className="text-accent-primary text-xs uppercase tracking-widest mb-4">La Historia Generada</h3>
        <div className="text-text-main whitespace-pre-line mb-8 font-ubuntu leading-relaxed">{result || "Generando..."}</div>
        <div className="flex gap-4">
          <button onClick={() => { setStep(1); setData({ protagonist: '', desire: '', conflict: '', risk: '', resolution: '' }); setResult(''); }} className="bg-borde text-text-main px-6 py-2 rounded font-bold hover:bg-accent-secondary transition-colors">Reiniciar</button>
          <button onClick={() => navigator.clipboard.writeText(result)} className="bg-accent-primary text-bg-pure px-6 py-2 rounded font-bold hover:opacity-90 transition-colors">Copiar</button>
        </div>
      </div>
    );
  }

  const steps = [
    { id: 1, label: "01. Protagonista", q: "¿Quién es el alma en el centro de esta historia?", key: "protagonist", placeholder: "Ej: Un relojero envejecido" },
    { id: 2, label: "02. Deseo", q: "¿Qué desea por encima de todo?", key: "desire", placeholder: "Ej: Detener el tiempo" },
    { id: 3, label: "03. Conflicto", q: "¿Qué se interpone en su camino?", key: "conflict", placeholder: "Ej: Sus máquinas dejan de funcionar" },
    { id: 4, label: "04. Riesgo", q: "¿Qué pierde si falla?", key: "risk", placeholder: "Ej: Sus recuerdos desaparecerán" },
    { id: 5, label: "05. Resolución", q: "¿Cómo termina todo?", key: "resolution", placeholder: "Ej: Aprende a valorar el tiempo" },
  ];
  const current = steps[step - 1];

  return (
    <div className="bg-bg-card p-8 border border-borde rounded-xl">
      <div className="h-1 bg-borde mb-8 overflow-hidden rounded-full">
        <div className="h-full bg-accent-primary transition-all duration-500" style={{ width: `${(step / 5) * 100}%` }}></div>
      </div>
      <h3 className="text-accent-primary text-xs uppercase tracking-widest mb-2">{current.label}</h3>
      <label className="block text-2xl mb-6 font-bold">{current.q}</label>
      <input 
        autoFocus
        value={(data as any)[current.key]}
        onChange={(e) => setData({ ...data, [current.key]: e.target.value })}
        placeholder={current.placeholder}
        className="w-full bg-transparent border-b-2 border-borde py-3 text-xl focus:border-accent-primary outline-none transition-colors mb-8"
        onKeyDown={(e) => e.key === 'Enter' && (step === 5 ? (setStep(6), generate()) : setStep(step + 1))}
      />
      <div className="flex gap-4">
        {step > 1 && <button onClick={() => setStep(step - 1)} className="bg-borde text-text-main px-8 py-3 rounded font-bold">Atrás</button>}
        <button onClick={() => step === 5 ? (setStep(6), generate()) : setStep(step + 1)} className="bg-accent-primary text-bg-pure px-8 py-3 rounded font-bold ml-auto">{step === 5 ? "Generar" : "Siguiente"}</button>
      </div>
    </div>
  );
}
