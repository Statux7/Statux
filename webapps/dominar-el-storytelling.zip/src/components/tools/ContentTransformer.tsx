import React, { useState } from 'react';
import { cn } from '../../lib/utils';

export default function ContentTransformer({ pyodide }: { pyodide: any }) {
  const [text, setText] = useState('');
  const [format, setFormat] = useState('tiktok');
  const [result, setResult] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const transform = async (viral = false) => {
    if (!text) return;
    setIsProcessing(true);
    try {
      await pyodide.runPythonAsync(`
import random
def transform_tiktok(text, viral=False):
    hooks = ["Lo que nadie te dice sobre...", "Dejé de hacer X y pasó esto:", "El secreto para...", "3 razones por las que estás fallando en..."]
    ctas = ["Sígueme para más", "Guarda esto si te sirvió", "Comenta 'YO' para enviarte info"]
    gancho = random.choice(hooks) if viral else "Atención a esto:"
    lines = [line.strip() for line in text.split('.') if line.strip()]
    res = f"🪝 GANCHO: {gancho}\\n\\n"
    for line in lines[:4]: res += f"• {line}\\n"
    res += f"\\n🚀 CTA: {random.choice(ctas)}"
    return res
def transform_instagram(text):
    sentences = [s.strip() for s in text.split('.') if len(s.strip()) > 5]
    slides = [f"SLIDE 1 (GANCHO):\\n{sentences[0][:50]}..."]
    for i, s in enumerate(sentences[1:6]): slides.append(f"SLIDE {i+2}:\\n{s}")
    slides.append(f"SLIDE FINAL:\\n¡Sígueme para desbloquear tu potencial!")
    return "|||".join(slides)
def transform_sales(text, viral=False):
    lines = [l.strip() for l in text.split('.') if l.strip()]
    p = lines[0] if lines else "Tu problema actual"
    cta = "ÚLTIMOS CUPOS DISPONIBLES. Haz clic ahora." if viral else "ACCEDE AHORA (Link en Bio)"
    return f"❌ PROBLEMA: {p}\\n\\n🔥 AGITACIÓN: Esto te está costando tiempo y dinero.\\n\\n✅ SOLUCIÓN: He creado la solución definitiva.\\n\\n🎯 CTA: {cta}"`);
      let res;
      if (format === 'tiktok') res = await pyodide.runPythonAsync(`transform_tiktok("""${text}""", ${viral ? 'True' : 'False'})`);
      else if (format === 'instagram') res = await pyodide.runPythonAsync(`transform_instagram("""${text}""")`);
      else res = await pyodide.runPythonAsync(`transform_sales("""${text}""", ${viral ? 'True' : 'False'})`);
      setResult(res);
    } catch (e) { console.error(e); } finally { setIsProcessing(false); }
  };

  return (
    <div className="space-y-8">
      <div className="bg-bg-card p-8 border border-borde rounded-xl">
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Pega tu historia aquí..." className="w-full h-40 bg-black border border-borde rounded-lg p-4 text-text-main outline-none focus:border-accent-primary transition-all resize-none mb-6" />
        <div className="grid grid-cols-3 gap-2 mb-6">
          {[{ id: 'tiktok', label: 'TikTok Script' }, { id: 'instagram', label: 'IG Carousel' }, { id: 'sales', label: 'Copy de Ventas' }].map((f) => (
            <button key={f.id} onClick={() => setFormat(f.id)} className={cn("py-3 text-[10px] font-black uppercase tracking-widest border rounded transition-all", format === f.id ? "border-accent-primary text-accent-primary bg-accent-primary/5" : "border-borde text-text-dim")}>{f.label}</button>
          ))}
        </div>
        <div className="flex gap-4">
          <button onClick={() => transform(false)} disabled={isProcessing} className="flex-[2] bg-accent-primary text-bg-pure py-4 rounded font-black uppercase tracking-widest hover:opacity-90 disabled:opacity-50 transition-all">Transformar</button>
          <button onClick={() => transform(true)} disabled={isProcessing} className="flex-1 border border-accent-secondary text-accent-primary py-4 rounded font-bold uppercase tracking-widest hover:bg-accent-primary/5 disabled:opacity-50 transition-all">Hacerlo Viral</button>
        </div>
      </div>
      {result && (
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="space-y-4">
            {format === 'instagram' ? result.split('|||').map((s: string, i: number) => (
              <div key={i} className="bg-zinc-900 p-6 border-l-4 border-accent-primary rounded-r-xl">
                <span className="text-[10px] text-accent-primary font-black uppercase mb-2 block">Diapositiva {i + 1}</span>
                <p className="text-text-main whitespace-pre-line">{s.split(':\\n')[1] || s}</p>
              </div>
            )) : <div className="bg-zinc-900 p-8 border-l-4 border-accent-primary rounded-r-xl"><p className="text-text-main whitespace-pre-line leading-relaxed">{result}</p></div>}
          </div>
        </div>
      )}
    </div>
  );
}
