import React, { useState } from 'react';
import { cn } from '../../lib/utils';

export default function PersuasionAnalyzer({ pyodide }: { pyodide: any }) {
  const [text, setText] = useState('');
  const [results, setResults] = useState<any>(null);

  const analyze = async () => {
    if (!text) return;
    try {
      const code = `
import re
def analyze(text):
    t = text.lower()
    palabras_fear = ["perder", "fracaso", "error", "miedo", "riesgo", "peligro"]
    palabras_desire = ["ganar", "lograr", "éxito", "mejorar", "crecer", "poder"]
    palabras_urgency = ["ahora", "rápido", "hoy", "urgente", "ya", "inmediato"]
    palabras_tension = ["pero", "sin embargo", "aunque", "no obstante"]
    fear = sum(1 for w in palabras_fear if w in t)
    desire = sum(1 for w in palabras_desire if w in t)
    urgency = sum(1 for w in palabras_urgency if w in t)
    tension_count = sum(1 for w in palabras_tension if w in t)
    emo_score = min(10, (fear + desire + urgency) * 2)
    ten_score = min(10, tension_count * 2.5)
    sentences = [s for s in text.split('.') if s]
    avg_len = len(text.split()) / len(sentences) if sentences else 0
    cla_score = max(0, min(10, 10 - (avg_len / 5)))
    per_score = round((emo_score + ten_score + cla_score) / 3, 1)
    suggs = []
    if emo_score < 5: suggs.append("Añade palabras con mayor carga emocional para aumentar el impacto.")
    if ten_score < 4: suggs.append("Introduce un conflicto claro usando palabras de contraste como 'pero'.")
    if cla_score < 6: suggs.append("Acorta las frases para mejorar la legibilidad y claridad.")
    return {"emo": emo_score, "ten": ten_score, "cla": round(cla_score, 1), "per": per_score, "suggs": suggs}
analyze("${text.replace(/"/g, '\\"').replace(/\n/g, ' ')}")`;
      const res = await pyodide.runPythonAsync(code);
      setResults(res.toJs());
    } catch (e) { console.error(e); }
  };

  const getTagArr = (score: number) => {
    if (score < 4) return { text: 'DÉBIL', color: '#FF4444' };
    if (score < 7) return { text: 'ACEPTABLE', color: '#FFD700' };
    return { text: 'FUERTE', color: '#5DD62C' };
  };

  return (
    <div className="space-y-8">
      <div className="bg-bg-card p-8 border border-borde rounded-xl">
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Pega tu historia o texto aquí..." className="w-full h-48 bg-black border border-borde rounded-lg p-4 text-text-main outline-none focus:border-accent-primary transition-all resize-none mb-6" />
        <button onClick={analyze} className="w-full bg-accent-primary text-bg-pure py-4 rounded-lg font-bold uppercase tracking-widest hover:opacity-90 transition-all">Analizar Texto</button>
      </div>
      {results && (
        <div className="animate-in fade-in slide-in-from-bottom-8 duration-700">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'Emoción', key: 'emo' },
              { label: 'Tensión', key: 'ten' },
              { label: 'Claridad', key: 'cla' },
              { label: 'Persuasión Final', key: 'per', highlight: true }
            ].map((m) => {
              const val = results.get(m.key);
              const tag = getTagArr(val);
              return (
                <div key={m.key} className={cn("bg-bg-card p-6 rounded-xl text-center border-b-4", m.highlight ? "bg-zinc-900 border-accent-primary" : "border-transparent")}>
                  <span className="text-[10px] uppercase tracking-widest text-text-dim block mb-2">{m.label}</span>
                  <span className="text-4xl font-black block mb-2" style={{ color: m.highlight ? '#5DD62C' : tag.color }}>{val}</span>
                  <span className="text-[10px] font-bold px-3 py-1 rounded-full" style={{ backgroundColor: tag.color + '22', color: tag.color }}>{tag.text}</span>
                </div>
              );
            })}
          </div>
          <div className="bg-bg-card p-8 rounded-xl border border-borde">
            <h3 className="text-accent-primary font-bold mb-4">Mejoras sugeridas</h3>
            <ul className="space-y-3 text-text-dim">
              {results.get('suggs').map((s: string, i: number) => (
                <li key={i} className="flex gap-3 items-start"><span className="text-accent-primary mt-1">•</span>{s}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
