import React, { useState } from 'react';

export default function SmartRewriter({ pyodide }: { pyodide: any }) {
  const [text, setText] = useState('');
  const [tone, setTone] = useState('Inspirador');
  const [results, setResults] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const process = async () => {
    if (!text) return;
    setIsProcessing(true);
    try {
      const code = `
import random
def rewrite(text, tone):
    emocional_hooks = ["Sé lo que se siente...", "Nadie habla de esto...", "Lo peor es..."]
    persuasiva_hooks = ["Si no haces esto...", "Estás perdiendo...", "Empieza ahora..."]
    if tone == "Agresivo":
        prefix_e, suffix_p = "Duele admitirlo, pero ", " No seas un espectador."
    elif tone == "Suave":
        prefix_e, suffix_p = "Imagina un momento donde ", " Tienes el potencial."
    else:
        prefix_e, suffix_p = "Existe una verdad oculta: ", " Es tu momento de brillar."
    emocional = f"{random.choice(emocional_hooks)} {prefix_e}{text.lower()}. Hay un deseo profundo que no estás escuchando."
    persuasiva = f"{text}. {random.choice(persuasiva_hooks)}{suffix_p}"
    cinematografica = f"...\\n{text.upper().replace('. ', '...\\n')}...\\nEL SILENCIO PESA."
    return {"emocional": emocional, "persuasiva": persuasiva, "cinematográfica": cinematografica, "best": "persuasiva" if tone == "Agresivo" else "emocional"}
rewrite("${text.replace(/"/g, '\\"').replace(/\n/g, ' ')}", "${tone}")`;
      const res = await pyodide.runPythonAsync(code);
      setResults(res.toJs());
    } catch (e) { console.error(e); } finally { setIsProcessing(false); }
  };

  return (
    <div className="space-y-8">
      <div className="bg-bg-card p-8 border border-borde rounded-xl">
        <textarea value={text} onChange={(e) => setText(e.target.value)} placeholder="Pega tu texto aquí..." className="w-full h-40 bg-black border border-borde rounded-lg p-4 text-text-main outline-none focus:border-accent-primary transition-all resize-none mb-6" />
        <div className="flex flex-col md:flex-row gap-4 items-center">
          <select value={tone} onChange={(e) => setTone(e.target.value)} className="w-full md:w-auto bg-bg-card border border-borde text-text-main px-6 py-3 rounded-lg outline-none focus:border-accent-primary">
            <option value="Inspirador">Tono: Inspirador</option>
            <option value="Agresivo">Tono: Agresivo</option>
            <option value="Suave">Tono: Suave</option>
          </select>
          <button onClick={process} disabled={isProcessing} className="w-full md:flex-1 bg-accent-primary text-bg-pure py-3 rounded-lg font-bold uppercase tracking-widest hover:opacity-90 disabled:opacity-50 transition-all">{isProcessing ? "Procesando..." : "Reescribir"}</button>
        </div>
      </div>
      {results && (
        <div className="grid gap-6">
          {['emocional', 'persuasiva', 'cinematográfica'].map((typeId, i) => {
            const labels: any = { emocional: 'Versión Emotiva', persuasiva: 'Versión Persuasiva', cinematográfica: 'Versión Cinematográfica' };
            const isBest = results.get('best') === typeId;
            return (
              <div key={typeId} className="bg-bg-card p-8 border border-borde rounded-2xl relative animate-in fade-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${i * 150}ms` }}>
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[10px] font-black bg-accent-secondary text-accent-primary px-3 py-1 rounded uppercase tracking-widest">{labels[typeId]}</span>
                  {isBest && <span className="bg-accent-primary text-bg-pure text-[10px] font-bold px-3 py-1 rounded uppercase">Mejor Opción</span>}
                </div>
                <p className="text-text-dim leading-relaxed italic mb-6">"{results.get(typeId)}"</p>
                <button onClick={() => navigator.clipboard.writeText(results.get(typeId))} className="text-xs text-text-dim underline hover:text-accent-primary transition-colors">Copiar versión</button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
