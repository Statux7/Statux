import React, { useState } from 'react';

export default function HookGenerator({ pyodide }: { pyodide: any }) {
  const [topic, setTopic] = useState('');
  const [hooks, setHooks] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  const generate = async () => {
    if (!topic) return;
    setIsGenerating(true);
    try {
      await pyodide.runPythonAsync(`
def create_hooks(topic):
    import random
    formulas = [
        f"Nadie te cuenta esto sobre {topic}, y es lo que más importa.",
        f"Estás haciendo esto mal en {topic} y por eso no avanzas.",
        f"Deja de hacer esto si quieres tener éxito real en {topic}.",
        f"Intenté {topic} durante 30 días y esto fue lo que sucedió...",
        f"Si ignoras esto en {topic}, te arrepentirás en menos de un año.",
        f"Después de años analizando {topic}, esta es la cruda verdad.",
        f"3 Pasos para dominar {topic} que los expertos no quieren que sepas.",
        f"¿Por qué el 99% de la gente falla en {topic}? Aquí la respuesta.",
        f"Este es el secreto de {topic} que cambiará tu perspectiva hoy mismo.",
        f"Lo que nadie te dice sobre {topic} te está costando dinero."
    ]
    return random.sample(formulas, k=random.randint(6, 10))`);
      const result = await pyodide.runPythonAsync(`create_hooks("${topic}")`);
      setHooks(result.toJs());
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="space-y-8">
      <div className="bg-bg-card p-2 border border-borde rounded-xl flex gap-2 focus-within:border-accent-secondary transition-all">
        <input 
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          placeholder="¿Cuál es tu tema? (ej. Dinero, Fitness, SEO...)"
          className="flex-1 bg-transparent border-none p-4 outline-none text-text-main"
          onKeyDown={(e) => e.key === 'Enter' && generate()}
        />
        <button onClick={generate} disabled={isGenerating} className="bg-accent-primary text-bg-pure px-8 rounded-lg font-bold hover:opacity-90 disabled:opacity-50 transition-all">
          {isGenerating ? "Procesando..." : "Generar ganchos"}
        </button>
      </div>
      <div className="grid gap-4">
        {hooks.map((hook, i) => (
          <div key={i} className="bg-bg-card p-6 border-l-4 border-accent-primary rounded-r-xl flex justify-between items-center group hover:bg-zinc-900 transition-colors animate-in fade-in slide-in-from-bottom-4 duration-500" style={{ animationDelay: `${i * 100}ms` }}>
            <p className="text-lg leading-relaxed max-w-[85%]">{hook}</p>
            <button 
              onClick={(e) => {
                navigator.clipboard.writeText(hook);
                const btn = e.currentTarget;
                btn.innerText = "¡Copiado!";
                btn.classList.add('bg-accent-primary', 'text-bg-pure');
                setTimeout(() => { btn.innerText = "Copiar"; btn.classList.remove('bg-accent-primary', 'text-bg-pure'); }, 1500);
              }}
              className="bg-borde text-text-dim px-4 py-2 rounded text-sm font-bold hover:text-text-main transition-all"
            >Copiar</button>
          </div>
        ))}
      </div>
    </div>
  );
}
