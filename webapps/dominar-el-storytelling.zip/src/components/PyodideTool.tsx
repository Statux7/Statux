import React, { useState, useEffect } from 'react';
import { Loader2 } from 'lucide-react';

interface PyodideToolProps {
  toolId: string;
  className?: string;
}

declare global {
  interface Window {
    loadPyodide: any;
  }
}

// Lazy loaded tool components
const StoryEngine = React.lazy(() => import('./tools/StoryEngine'));
const HookGenerator = React.lazy(() => import('./tools/HookGenerator'));
const PersuasionAnalyzer = React.lazy(() => import('./tools/PersuasionAnalyzer'));
const SmartRewriter = React.lazy(() => import('./tools/SmartRewriter'));
const ContentTransformer = React.lazy(() => import('./tools/ContentTransformer'));

export const PyodideTool: React.FC<PyodideToolProps> = ({ toolId }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pyodide, setPyodide] = useState<any>(null);

  useEffect(() => {
    let isMounted = true;

    const init = async () => {
      try {
        if (!window.loadPyodide) {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/pyodide/v0.25.0/full/pyodide.js';
          await new Promise((resolve, reject) => {
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
          });
        }
        
        if (!isMounted) return;
        const p = await window.loadPyodide();
        if (!isMounted) return;
        
        setPyodide(p);
        setIsLoading(false);
      } catch (err) {
        if (isMounted) {
          setError('Error cargando el motor de Python');
          setIsLoading(false);
        }
      }
    };

    init();
    return () => { isMounted = false; };
  }, []);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center p-12 bg-bg-card border border-borde rounded-xl">
        <Loader2 className="w-8 h-8 text-accent-primary animate-spin mb-4" />
        <p className="text-text-dim text-sm uppercase tracking-widest">Inicializando motor narrativo...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-8 bg-bg-card border border-red-900/50 rounded-xl text-center">
        <p className="text-red-500">{error}</p>
      </div>
    );
  }

  return (
    <React.Suspense fallback={<div className="p-12 text-center text-text-dim">Cargando herramienta...</div>}>
      {toolId === 'story-engine' && <StoryEngine pyodide={pyodide} />}
      {toolId === 'hook-generator' && <HookGenerator pyodide={pyodide} />}
      {toolId === 'persuasion-analyzer' && <PersuasionAnalyzer pyodide={pyodide} />}
      {toolId === 'smart-rewriter' && <SmartRewriter pyodide={pyodide} />}
      {toolId === 'content-transformer' && <ContentTransformer pyodide={pyodide} />}
    </React.Suspense>
  );
};
